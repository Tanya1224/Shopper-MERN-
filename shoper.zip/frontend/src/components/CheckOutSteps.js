import React from "react";
import { Nav } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";

const CheckOutSteps = ({ stap1, stap2, stap3, stap4 }) => {
  return (
    <Nav className='justify-content-center me-4'>
      <Nav.Item>
        {stap1 ? (
          <LinkContainer to='/login'>
            <Nav.Link>sign in</Nav.Link>
          </LinkContainer>
        ) : (
          <Nav.Link disabled>sign in</Nav.Link>
        )}
      </Nav.Item>

      <Nav.Item>
        {stap2 ? (
          <LinkContainer to='/shipping'>
            <Nav.Link>Shipping</Nav.Link>
          </LinkContainer>
        ) : (
          <Nav.Link disabled>Shipping</Nav.Link>
        )}
      </Nav.Item>

      <Nav.Item>
        {stap3 ? (
          <LinkContainer to='/payment'>
            <Nav.Link>Payment</Nav.Link>
          </LinkContainer>
        ) : (
          <Nav.Link disabled>Payment</Nav.Link>
        )}
      </Nav.Item>

      <Nav.Item>
        {stap4 ? (
          <LinkContainer to='/placeorder'>
            <Nav.Link>Place Order</Nav.Link>
          </LinkContainer>
        ) : (
          <Nav.Link disabled>Place Order</Nav.Link>
        )}
      </Nav.Item>
    </Nav>
  );
};

export default CheckOutSteps;
